package dev.auramotion.anim;

/** Tunable numbers for the run styles (all in radians or 0..1 weights). */
public final class RunProfile {
    public final float leanSprint, leanJog, armBase, armFwd, armBack, tuck, twist;
    public final float kickBack, kickFront, bob, sway, elbow, kneeBack, kneeFront, headFollow, elbowSlope;

    private RunProfile(float leanSprint, float leanJog, float armBase, float armFwd, float armBack, float tuck,
                       float twist, float kickBack, float kickFront, float bob, float sway,
                       float elbow, float kneeBack, float kneeFront, float headFollow, float elbowSlope) {
        this.leanSprint = leanSprint;
        this.leanJog = leanJog;
        this.armBase = armBase;
        this.armFwd = armFwd;
        this.armBack = armBack;
        this.tuck = tuck;
        this.twist = twist;
        this.kickBack = kickBack;
        this.kickFront = kickFront;
        this.bob = bob;
        this.sway = sway;
        this.elbow = elbow;
        this.kneeBack = kneeBack;
        this.kneeFront = kneeFront;
        this.headFollow = headFollow;
        this.elbowSlope = elbowSlope;
    }

    /** Balanced: moderate lean, arms mostly in front. */
    public static final RunProfile ATHLETIC =
            new RunProfile(0.30F, 0.07F, 0.45F, 0.55F, 0.30F, 0.10F, 0.13F, 0.25F, 0.10F, 0.06F, 0.03F, 1.15F, 1.10F, 0.35F, 0.15F, -0.25F);

    /** Energetic "action" feel: deeper lean, bigger arm drive, high knees, deeper elbow/knee bend. */
    public static final RunProfile ACTION =
            new RunProfile(0.38F, 0.10F, 0.30F, 0.90F, 0.40F, 0.14F, 0.18F, 0.40F, 0.25F, 0.09F, 0.04F, 1.40F, 1.30F, 0.60F, 0.20F, -0.25F);

    /**
     * "Fresh" look (reference sheet): deep forward lean with the head following it, elbows bent ~90 degrees with the
     * fists at chest height and elbows slightly out. The forward-swinging arm bends the elbow most (~100 degrees),
     * the trailing arm stays almost straight; stride kept to about 110 degrees (vanilla's leg swing is scaled down by 30%) with moderate knee bends.
     */
    public static final RunProfile FRESH =
            new RunProfile(0.40F, 0.10F, 0.05F, 0.55F, 0.75F, -0.25F, 0.10F, -0.30F, -0.30F, 0.05F, 0.03F, 1.00F, 0.85F, 0.55F, 0.50F, 0.80F);

    public static RunProfile of(String style) {
        if ("fresh".equals(style)) {
            return FRESH;
        }
        return "action".equals(style) ? ACTION : ATHLETIC;
    }
}
