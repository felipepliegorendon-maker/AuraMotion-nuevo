package dev.auramotion.anim;

/** Tiny cost counter so the real CPU cost of AuraMotion can be measured on the device (/auramotion perf). */
public final class PerfStats {
    private static long nanos;
    private static long calls;
    private static long since = System.nanoTime();

    private PerfStats() {
    }

    public static void add(long n) {
        nanos += n;
        calls++;
    }

    /** Returns a report for the window since the last call and starts a new window. */
    public static String reportAndReset() {
        long now = System.nanoTime();
        double secs = Math.max(0.001D, (now - since) / 1.0E9D);
        double perCallUs = calls == 0 ? 0.0D : nanos / 1000.0D / calls;
        double msPerSec = nanos / 1.0E6D / secs;
        String out = String.format("AuraMotion: %.1f µs por llamada, %d llamadas, ≈%.3f ms de CPU por segundo (ventana %.1f s)",
                perCallUs, calls, msPerSec, secs);
        nanos = 0L;
        calls = 0L;
        since = now;
        return out;
    }
}
