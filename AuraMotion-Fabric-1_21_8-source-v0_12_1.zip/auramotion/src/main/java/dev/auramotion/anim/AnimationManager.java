package dev.auramotion.anim;

import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.math.MathHelper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;

/**
 * Client-side only emotes for the local player (visual, no networking).
 * Clips live in config/auramotion/animations/*.json. Render thread only.
 */
public final class AnimationManager {
    private static final float FADE = 0.25F;
    private static final Map<String, AnimationClip> CLIPS = new TreeMap<>();
    private static final float[] TMP = new float[3];

    private static AnimationClip active;
    private static long startNanos;
    private static boolean stopping;
    private static long stopNanos;

    private AnimationManager() {
    }

    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("auramotion").resolve("animations");
    }

    public static void load() {
        CLIPS.clear();
        active = null;
        Path dir = dir();
        try {
            Files.createDirectories(dir);
            boolean empty;
            try (Stream<Path> s = Files.list(dir)) {
                empty = s.noneMatch(p -> p.toString().endsWith(".json"));
            }
            if (empty) {
                writeSamples(dir);
            }
            try (Stream<Path> s = Files.list(dir)) {
                for (Path p : (Iterable<Path>) s::iterator) {
                    String file = p.getFileName().toString();
                    if (!file.endsWith(".json")) {
                        continue;
                    }
                    String name = file.substring(0, file.length() - 5).toLowerCase();
                    try {
                        CLIPS.put(name, AnimationClip.parse(name,
                                JsonParser.parseString(Files.readString(p)).getAsJsonObject()));
                    } catch (Exception ignored) {
                        // Skip malformed clips; never crash the client over a JSON typo.
                    }
                }
            }
        } catch (IOException ignored) {
            // Emotes are optional.
        }
    }

    private static void writeSamples(Path dir) throws IOException {
        Files.writeString(dir.resolve("wave.json"), """
                {
                  "length": 2.0,
                  "loop": false,
                  "tracks": {
                    "rightArm": [
                      {"t": 0.0, "pitch": 0,    "roll": 0},
                      {"t": 0.3, "pitch": -150, "roll": 10},
                      {"t": 0.6, "pitch": -150, "roll": 35},
                      {"t": 0.9, "pitch": -150, "roll": 10},
                      {"t": 1.2, "pitch": -150, "roll": 35},
                      {"t": 1.5, "pitch": -150, "roll": 10},
                      {"t": 2.0, "pitch": 0,    "roll": 0}
                    ]
                  }
                }
                """);
        Files.writeString(dir.resolve("bow.json"), """
                {
                  "length": 2.0,
                  "loop": false,
                  "tracks": {
                    "body": [
                      {"t": 0.0, "pitch": 0},
                      {"t": 0.6, "pitch": 40},
                      {"t": 1.3, "pitch": 40},
                      {"t": 2.0, "pitch": 0}
                    ],
                    "head": [
                      {"t": 0.0, "pitch": 0},
                      {"t": 0.6, "pitch": 15},
                      {"t": 1.3, "pitch": 15},
                      {"t": 2.0, "pitch": 0}
                    ]
                  }
                }
                """);
    }

    public static List<String> names() {
        return new ArrayList<>(CLIPS.keySet());
    }

    public static boolean play(String name) {
        AnimationClip clip = CLIPS.get(name.toLowerCase());
        if (clip == null) {
            return false;
        }
        active = clip;
        startNanos = System.nanoTime();
        stopping = false;
        return true;
    }

    /** Fades the current emote out. */
    public static void stop() {
        if (active != null && !stopping) {
            stopping = true;
            stopNanos = System.nanoTime();
        }
    }

    public static boolean isActive() {
        return active != null && !stopping;
    }

    /** Overrides the model rotations of the parts the clip animates, blended by fade weight. */
    public static void apply(PlayerEntityModel model) {
        AnimationClip clip = active;
        if (clip == null) {
            return;
        }
        long now = System.nanoTime();
        float elapsed = (now - startNanos) / 1.0E9F;

        if (!stopping && !clip.loop && elapsed >= clip.length) {
            stopping = true;
            stopNanos = startNanos + (long) (clip.length * 1.0E9F);
        }
        float w = MathHelper.clamp(elapsed / FADE, 0.0F, 1.0F);
        if (stopping) {
            float out = 1.0F - (now - stopNanos) / 1.0E9F / FADE;
            if (out <= 0.0F) {
                active = null;
                return;
            }
            w = Math.min(w, out);
        }
        float t = clip.loop ? elapsed % clip.length : Math.min(elapsed, clip.length);

        float bodyBefore = model.body.pitch;
        blend(clip, "head", model.head, t, w);
        blend(clip, "body", model.body, t, w);
        blend(clip, "rightArm", model.rightArm, t, w);
        blend(clip, "leftArm", model.leftArm, t, w);
        blend(clip, "rightLeg", model.rightLeg, t, w);
        blend(clip, "leftLeg", model.leftLeg, t, w);
        float dBody = model.body.pitch - bodyBefore;
        if (Math.abs(dBody) > 0.002F) {
            SecondaryMotion.shiftUpper(model, dBody);
        }
    }

    private static void blend(AnimationClip clip, String name, ModelPart part, float t, float w) {
        if (clip.sample(name, t, TMP)) {
            part.pitch = MathHelper.lerp(w, part.pitch, TMP[0]);
            part.yaw = MathHelper.lerp(w, part.yaw, TMP[1]);
            part.roll = MathHelper.lerp(w, part.roll, TMP[2]);
        }
    }
}
