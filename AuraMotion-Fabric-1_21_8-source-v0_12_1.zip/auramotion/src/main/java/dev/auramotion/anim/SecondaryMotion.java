package dev.auramotion.anim;

import dev.auramotion.config.AuraMotionConfig;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Applies small additive rotations on top of the vanilla pose.
 * Rotation-only on purpose: pivots are left alone to stay compatible with other mods.
 * Sign convention: body/head pitch + = forward; right arm roll + / left arm roll - = outward;
 * arm pitch - = forward/up; body yaw - = right shoulder forward.
 */
public final class SecondaryMotion {
    private SecondaryMotion() {
    }

    private static void applyCore(PlayerEntityModel model, PlayerMotionState s, float age,
                                  float limbAmplitude, float limbProgress) {
        AuraMotionConfig c = AuraMotionConfig.get();
        float k = c.intensity * s.master;
        if (k <= 0.001F) {
            return;
        }
        float armK = k * s.armWeight;
        float movement = MathHelper.clamp(limbAmplitude, 0.0F, 1.0F);

        if (c.idleBreathing) {
            float phase = age * 0.075F + s.phase;
            float idleWeight = 1.0F - movement;
            float idle = MathHelper.sin(phase) * 0.018F * idleWeight * armK;
            model.rightArm.roll += idle;
            model.leftArm.roll -= idle;
            model.body.yaw += MathHelper.sin(phase * 0.5F) * 0.006F * idleWeight * k;
            // slow weight shift and tiny glances so standing still does not look frozen
            model.body.roll += MathHelper.sin(age * 0.03F + s.phase) * 0.02F * idleWeight * k;
            model.head.yaw += MathHelper.sin(age * 0.021F + s.phase * 2.0F) * 0.05F * idleWeight * k;
        }

        if (c.walkSway) {
            float gait = MathHelper.sin(limbProgress * 0.5F);
            model.body.yaw += gait * 0.012F * movement * k;
        }

        boolean athletic = !"classic".equals(c.runStyle);
        if (athletic) {
            applyAthletic(model, s, c, k, movement);
        }

        if (!athletic && c.sprintLean && s.lean > 0.001F) {
            float lean = s.lean * k;
            model.body.pitch += lean * 0.14F;
            model.head.pitch += lean * 0.05F; // the head is not a child of the torso: + tilts it forward
        }

        if (!athletic && c.runDetail && movement > 0.05F) {
            float run = s.lean; // 0 walking .. 1 sprinting
            float w = movement * (0.35F + 0.65F * run) * k;
            // Stronger shoulder/hip drive (scales the vanilla swing, so it stays in phase).
            float armDrive = 1.0F + 0.30F * run * armK;
            model.rightArm.pitch *= armDrive;
            model.leftArm.pitch *= armDrive;
            float legDrive = 1.0F + 0.15F * run * k;
            model.rightLeg.pitch *= legDrive;
            model.leftLeg.pitch *= legDrive;
            // Torso counter-twist follows the arms; head keeps looking forward.
            float twist = (model.rightArm.pitch - model.leftArm.pitch) * 0.05F * w * s.armWeight;
            model.body.yaw += twist;
            model.head.yaw -= twist;
            // Hip sway follows the legs.
            float sway = (model.rightLeg.pitch - model.leftLeg.pitch) * 0.0125F * w;
            model.body.roll += sway;
            model.head.roll -= sway;
            // Arms open slightly when sprinting.
            float out = 0.07F * run * armK;
            model.rightArm.roll += out;
            model.leftArm.roll -= out;
        }

        if (c.turnFollow && Math.abs(s.turn) > 0.002F) {
            // Torso lags slightly behind the turn; arms trail outward on the swing side.
            model.body.yaw -= s.turn * 0.10F * k;
            float trail = s.turn * 0.12F * armK;
            model.rightArm.roll += Math.max(0.0F, -trail);
            model.leftArm.roll -= Math.max(0.0F, trail);
        }

        if (c.airPose && s.air > 0.001F) {
            float out = (0.10F * s.air + 0.35F * s.fall) * armK;
            model.rightArm.roll += out;
            model.leftArm.roll -= out;
            float up = s.rise * 0.28F * armK;
            model.rightArm.pitch -= up;
            model.leftArm.pitch -= up;
        }

        if (c.landingImpact && s.land > 0.001F) {
            float land = s.land * k;
            model.body.pitch += land * 0.18F;
            model.head.pitch += land * 0.10F;
            float spread = land * 0.20F * s.armWeight;
            model.rightArm.roll += spread;
            model.leftArm.roll -= spread;
        }

        if (c.swingAnimations && s.swing > 0.001F) {
            applySwing(model, s, k);
        }
    }

    /** Standing pose: the full overlay. */
    public static void apply(PlayerEntityModel model, PlayerMotionState s, float age,
                             float limbAmplitude, float limbProgress) {
        float basePitch = model.body.pitch;
        applyCore(model, s, age, limbAmplitude, limbProgress);
        ambient(model, s, age, limbAmplitude, 0);
        finishLean(model, basePitch);
    }

    /** Other vanilla poses we decorate: 1 = sneaking, 2 = swimming. */
    public static void applyOther(PlayerEntityModel model, PlayerMotionState s, int poseId, float age,
                                  float limbAmplitude) {
        float basePitch = model.body.pitch;
        ambient(model, s, age, limbAmplitude, poseId);
        finishLean(model, basePitch);
    }

    /** The torso rotates around its top (the neck); make it behave as if it pivoted at the hips. */
    private static void finishLean(PlayerEntityModel model, float basePitch) {
        float dPitch = model.body.pitch - basePitch;
        if (Math.abs(dPitch) > 0.002F) {
            shiftUpper(model, dPitch);
        }
    }

    /** Climbing, strafe/backpedal lean, item use, sneak detail and swim undulation (config ambientAnimations). */
    private static void ambient(PlayerEntityModel m, PlayerMotionState s, float age, float limbAmplitude, int poseId) {
        AuraMotionConfig c = AuraMotionConfig.get();
        if (!c.ambientAnimations) {
            return;
        }
        float k = c.intensity;
        float mv = MathHelper.clamp(limbAmplitude, 0.0F, 1.0F);

        // Strafe / backpedal: lean into the sideways direction, lean back when walking backwards.
        if (poseId < 2 && mv > 0.15F && (Math.abs(s.side) > 0.05F || s.fwd < -0.05F)) {
            float back = MathHelper.clamp(-s.fwd, 0.0F, 1.0F);
            m.body.pitch -= 0.07F * back * mv * k;
            float roll = -s.side * 0.07F * mv * k;
            m.body.roll += roll;
            m.head.roll -= roll * 0.8F;
        }

        if (poseId == 1) {
            // Sneaking: torso follows the arm swing a little, hips sway.
            float twist = (m.rightArm.pitch - m.leftArm.pitch) * 0.04F * mv * k;
            m.body.yaw += twist;
            m.head.yaw -= twist;
            float sway = (m.rightLeg.pitch - m.leftLeg.pitch) * 0.02F * mv * k;
            m.body.roll += sway;
            m.head.roll -= sway;
        } else if (poseId == 2) {
            // Swimming: the body undulates.
            float wave = MathHelper.sin(age * 0.35F + s.phase) * mv * k;
            m.body.yaw += wave * 0.12F;
            m.head.yaw -= wave * 0.10F;
            m.body.roll += wave * 0.04F;
        }

        // Climbing: arms reach up alternately, legs step.
        if (poseId == 0 && s.climb > 0.01F) {
            float w = MathHelper.clamp(s.climb * k, 0.0F, 1.0F);
            float a = MathHelper.sin(s.climbPhase);
            m.rightArm.pitch = MathHelper.lerp(w, m.rightArm.pitch, -2.45F + 0.45F * a);
            m.leftArm.pitch = MathHelper.lerp(w, m.leftArm.pitch, -2.45F - 0.45F * a);
            m.rightArm.roll = MathHelper.lerp(w, m.rightArm.roll, 0.15F);
            m.leftArm.roll = MathHelper.lerp(w, m.leftArm.roll, -0.15F);
            m.rightLeg.pitch = MathHelper.lerp(w, m.rightLeg.pitch, -0.25F - 0.50F * (0.5F - 0.5F * a));
            m.leftLeg.pitch = MathHelper.lerp(w, m.leftLeg.pitch, -0.25F - 0.50F * (0.5F + 0.5F * a));
            m.body.pitch += 0.06F * w;
        }

        // Riding.
        if (poseId == 0 && s.rideW > 0.01F) {
            float w = MathHelper.clamp(s.rideW * k, 0.0F, 1.0F);
            if (s.mountKind == 1) {
                float sp = MathHelper.clamp(s.rideSpeed / 0.30F, 0.0F, 1.0F);
                m.body.pitch += (0.04F + 0.14F * sp) * w; // lean into the gallop
                float bob = MathHelper.sin(s.ridePhase) * sp * w;
                m.body.pitch += bob * 0.04F;
                m.head.pitch -= bob * 0.04F; // head stays steadier than the torso
                m.rightArm.pitch = MathHelper.lerp(w, m.rightArm.pitch, -0.95F); // hands on the reins
                m.leftArm.pitch = MathHelper.lerp(w, m.leftArm.pitch, -0.95F);
                m.rightArm.roll = MathHelper.lerp(w, m.rightArm.roll, -0.10F);
                m.leftArm.roll = MathHelper.lerp(w, m.leftArm.roll, 0.10F);
            } else if (s.mountKind == 2) {
                float row = MathHelper.clamp(s.rideSpeed / 0.12F, 0.0F, 1.0F);
                float stroke = MathHelper.sin(s.ridePhase) * 0.55F * row;
                float wr = w * (0.35F + 0.65F * row);
                m.rightArm.pitch = MathHelper.lerp(wr, m.rightArm.pitch, -0.9F + stroke);
                m.leftArm.pitch = MathHelper.lerp(wr, m.leftArm.pitch, -0.9F - stroke);
                m.rightArm.roll += 0.12F * wr;
                m.leftArm.roll -= 0.12F * wr;
                m.body.pitch += (0.04F + 0.05F * MathHelper.sin(s.ridePhase * 2.0F)) * wr;
            }
        }

        // Elytra: arms swept back, legs flutter.
        if (poseId == 3) {
            float w = MathHelper.clamp(s.glideW * k, 0.0F, 1.0F);
            float flutter = MathHelper.sin(age * 0.5F + s.phase) * w;
            m.rightLeg.pitch += flutter * 0.07F;
            m.leftLeg.pitch -= flutter * 0.07F;
            m.rightLeg.roll += 0.06F * w;
            m.leftLeg.roll -= 0.06F * w;
            m.rightArm.roll += 0.25F * w;
            m.leftArm.roll -= 0.25F * w;
            m.rightArm.pitch += 0.25F * w;
            m.leftArm.pitch += 0.25F * w;
        }

        // Shield block: braced stance.
        if (poseId < 2 && s.blockW > 0.01F) {
            float w = MathHelper.clamp(s.blockW * k, 0.0F, 1.0F);
            m.body.pitch += 0.08F * w;
            m.head.pitch += 0.04F * w;
            m.rightLeg.pitch -= 0.15F * w;
            m.leftLeg.pitch += 0.12F * w;
        }

        // Fishing rod held out.
        if (poseId < 2 && s.fishW > 0.01F) {
            float w = s.fishW * k;
            m.body.pitch += 0.05F * w;
            m.head.pitch += 0.04F * w;
            ModelPart rod = s.swingRight ? m.rightArm : m.leftArm;
            rod.roll += MathHelper.sin(age * 0.4F) * 0.03F * w;
        }

        // Damage flinch (cosmetic only).
        if (c.hitReaction && s.hurt > 0.01F) {
            float h = s.hurt * s.hurt * k;
            m.body.pitch -= 0.28F * h;
            m.head.pitch -= 0.22F * h;
            m.rightArm.roll += 0.30F * h;
            m.leftArm.roll -= 0.30F * h;
        }

        // Item use.
        if (poseId != 2 && s.useW > 0.01F) {
            float w = s.useW * k;
            switch (s.useKind) {
                case 1 -> m.head.pitch += (0.06F + 0.05F * MathHelper.sin(age * 1.6F)) * w; // chewing
                case 3 -> m.head.pitch -= 0.18F * w; // head back to drink
                case 4 -> { // brushing
                    ModelPart arm = s.swingRight ? m.rightArm : m.leftArm;
                    arm.pitch += MathHelper.sin(age * 1.4F) * 0.30F * w;
                    m.body.yaw += MathHelper.sin(age * 0.7F) * 0.05F * w;
                }
                case 6 -> { // trident wind-up
                    m.body.pitch -= 0.08F * w;
                    m.rightArm.roll += MathHelper.sin(age * 1.1F) * 0.015F * w;
                }
                case 7 -> { // goat horn
                    m.head.pitch -= 0.25F * w;
                    m.body.pitch -= 0.06F * w;
                }
                case 2 -> {
                    m.body.pitch -= 0.05F * w;
                    float shake = MathHelper.sin(age * 1.3F) * 0.012F * w;
                    m.rightArm.roll += shake;
                    m.leftArm.roll -= shake;
                }
                default -> {
                }
            }
        }
    }

    /**
     * Moves the neck/shoulders so a forward lean of dPitch happens around the hips: the upper body
     * moves forward and slightly down instead of the hips swinging backward away from the legs.
     * Model space: +originZ = backwards, +originY = down. Origins are reset by vanilla every frame.
     */
    public static void shiftUpper(PlayerEntityModel m, float dPitch) {
        float sin = MathHelper.sin(dPitch);
        float cos = MathHelper.cos(dPitch);
        float topZ = 12.0F * sin;           // neck / top of torso is 12 px above the hips
        float topY = 12.0F * (1.0F - cos);
        float armZ = 10.0F * sin;           // shoulder joint is 10 px above the hips
        float armY = 10.0F * (1.0F - cos);
        m.body.originZ -= topZ;
        m.body.originY += topY;
        m.head.originZ -= topZ;
        m.head.originY += topY;
        m.rightArm.originZ -= armZ;
        m.rightArm.originY += armY;
        m.leftArm.originZ -= armZ;
        m.leftArm.originY += armY;
    }

    /**
     * Athletic run: forward lean, arms held forward and pumping (bent-arm look), legs with a longer trailing kick,
     * counter-twisting torso, head bob. Limbs are rigid in the vanilla model (no elbows/knees), so this is an
     * approximation done with rotations only. u is the vanilla swing signal (+1 = right arm fully forward).
     */
    private static void applyAthletic(PlayerEntityModel m, PlayerMotionState s, AuraMotionConfig c,
                                      float k, float movement) {
        RunProfile p = RunProfile.of(c.runStyle);
        float run = s.lean; // 0 jog .. 1 sprint
        float rw = movement * (0.25F + 0.75F * run); // how much of the run pose applies
        float jog = movement * (1.0F - run);

        if (c.sprintLean) {
            float lean = (p.leanJog * jog + p.leanSprint * run) * k;
            m.body.pitch += lean;
            m.head.pitch += lean * p.headFollow; // 0 = gaze stays level, 0.5 = head follows half of the lean
        }
        if (!c.runDetail || rw < 0.02F) {
            return;
        }

        float t = MathHelper.clamp(rw * k, 0.0F, 1.0F);
        float ta = t * s.armWeight;
        float u = (m.leftArm.pitch - m.rightArm.pitch) * 0.5F;

        // Arms: held forward, swing mostly in front of the body, elbows tucked toward the torso.
        m.rightArm.pitch = MathHelper.lerp(ta, m.rightArm.pitch, pump(u, p));
        m.leftArm.pitch = MathHelper.lerp(ta, m.leftArm.pitch, pump(-u, p));
        m.rightArm.roll -= p.tuck * ta;
        m.leftArm.roll += p.tuck * ta;

        // Legs: longer trailing kick, slightly higher knee.
        m.rightLeg.pitch = kick(m.rightLeg.pitch, t, p);
        m.leftLeg.pitch = kick(m.leftLeg.pitch, t, p);

        // Torso counter-twist, head stays level; bob twice per stride; hip sway.
        float twist = -u * p.twist * rw * k * s.armWeight;
        m.body.yaw += twist;
        m.head.yaw -= twist;
        m.head.pitch += (0.5F - Math.abs(u)) * p.bob * rw * k;
        float sway = (m.rightLeg.pitch - m.leftLeg.pitch) * p.sway * rw * k;
        m.body.roll += sway;
        m.head.roll -= sway;
    }

    private static float pump(float u, RunProfile p) {
        return u > 0.0F ? -p.armBase - p.armFwd * u : -p.armBase - p.armBack * u;
    }

    private static float kick(float pitch, float t, RunProfile p) {
        return pitch > 0.0F ? pitch * (1.0F + p.kickBack * t) : pitch * (1.0F + p.kickFront * t);
    }

    /** Follow-through on top of vanilla's swing (peak of vanilla's strike is around p = 0.2). */
    private static void applySwing(PlayerEntityModel model, PlayerMotionState s, float k) {
        float p = MathHelper.clamp(s.swing, 0.0F, 1.0F);
        float inv = 1.0F - p;
        float strike = MathHelper.sin((1.0F - inv * inv * inv) * MathHelper.PI); // matches vanilla's curve
        float bell = MathHelper.sin(p * MathHelper.PI); // slower body weight shift

        float armExtra, out, bodyAmt, headAmt, lunge;
        switch (s.swingStyle) {
            case 1 -> { armExtra = 0.15F; out = 0.20F; bodyAmt = 0.10F; headAmt = 0.04F; lunge = 0.22F; } // sword slash
            case 2 -> { armExtra = 0.35F; out = 0.08F; bodyAmt = 0.18F; headAmt = 0.10F; lunge = 0.12F; } // pickaxe
            case 3 -> { armExtra = 0.45F; out = 0.05F; bodyAmt = 0.14F; headAmt = 0.06F; lunge = 0.25F; } // throw
            case 4 -> { armExtra = 0.30F; out = 0.15F; bodyAmt = 0.14F; headAmt = 0.08F; lunge = 0.15F; } // axe
            case 5 -> { armExtra = 0.20F; out = 0.06F; bodyAmt = 0.25F; headAmt = 0.14F; lunge = 0.10F; } // shovel
            case 6 -> { armExtra = 0.25F; out = 0.30F; bodyAmt = 0.10F; headAmt = 0.06F; lunge = 0.12F; } // hoe
            default -> { armExtra = 0.10F; out = 0.08F; bodyAmt = 0.05F; headAmt = 0.02F; lunge = 0.08F; }
        }

        ModelPart arm = s.swingRight ? model.rightArm : model.leftArm;
        float side = s.swingRight ? 1.0F : -1.0F;
        arm.pitch -= strike * armExtra * k;
        arm.roll += side * strike * out * k;

        model.body.pitch += bell * bodyAmt * k;
        model.head.pitch += bell * headAmt * k;

        // Weight shift: the leg opposite the swinging arm steps forward.
        ModelPart front = s.swingRight ? model.leftLeg : model.rightLeg;
        ModelPart back = s.swingRight ? model.rightLeg : model.leftLeg;
        front.pitch -= bell * lunge * k;
        back.pitch += bell * lunge * 0.6F * k;
    }
}
