package dev.auramotion.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Tiny JSON config stored at config/auramotion.json. No extra dependencies. */
public final class AuraMotionConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static AuraMotionConfig instance = new AuraMotionConfig();

    public boolean enabled = true;
    /** Global multiplier for every effect (0 = off, 1 = default, 2 = double). */
    public float intensity = 1.0F;
    public boolean idleBreathing = true;
    public boolean walkSway = true;
    public boolean sprintLean = true;
    public boolean airPose = true;
    public boolean landingImpact = true;
    public boolean turnFollow = true;
    /** Extra running detail: stronger limb drive, torso counter-twist, hip sway. */
    public boolean runDetail = true;
    /** Climbing, strafe/backpedal lean, eating/drinking/bow tension, sneak detail, swim undulation. */
    public boolean ambientAnimations = true;
    /** Short cosmetic flinch when you or another player takes damage (no gameplay effect). */
    public boolean hitReaction = true;
    /** EXPERIMENTAL: real elbows/knees by splitting limbs. Needs a restart (or F3+T) after changing. */
    public boolean bentLimbs = false;
    /** "fresh" (matches the reference sheet), "athletic", "action" or "classic" (v0.6 style). */
    public String runStyle = "fresh";
    /** Attack / mining follow-through (sword, pickaxe, axe, shovel, hoe). */
    public boolean swingAnimations = true;
    /** Players farther than this many blocks get no AuraMotion work at all (saves CPU). */
    public float maxDistance = 24.0F;

    public static AuraMotionConfig get() {
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("auramotion.json");
    }

    public static void load() {
        Path file = path();
        AuraMotionConfig loaded = null;
        if (Files.isRegularFile(file)) {
            try {
                loaded = GSON.fromJson(Files.readString(file), AuraMotionConfig.class);
            } catch (Exception ignored) {
                // Corrupt file: fall back to defaults and rewrite it below.
            }
        }
        instance = loaded != null ? loaded : new AuraMotionConfig();
        instance.sanitize();
        save();
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (IOException ignored) {
            // Config is optional; never crash the client over it.
        }
    }

    private void sanitize() {
        if (Float.isNaN(intensity)) {
            intensity = 1.0F;
        }
        intensity = Math.max(0.0F, Math.min(2.0F, intensity));
        if (!"athletic".equals(runStyle) && !"action".equals(runStyle) && !"fresh".equals(runStyle)
                && !"classic".equals(runStyle)) {
            runStyle = "fresh";
        }
        if (Float.isNaN(maxDistance)) {
            maxDistance = 24.0F;
        }
        maxDistance = Math.max(4.0F, Math.min(128.0F, maxDistance));
    }

    public void setRunStyle(String style) {
        this.runStyle = style;
        sanitize();
    }

    public void setIntensity(float value) {
        this.intensity = value;
        sanitize();
    }
}
