package dev.auramotion.mixin;

import dev.auramotion.anim.AuraMotionStateAccess;
import dev.auramotion.anim.PlayerMotionState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(PlayerEntityRenderState.class)
public abstract class PlayerEntityRenderStateMixin implements AuraMotionStateAccess {
    @Unique
    private PlayerMotionState auramotion$motion;

    @Override
    public PlayerMotionState auramotion$getMotion() {
        return this.auramotion$motion;
    }

    @Override
    public void auramotion$setMotion(PlayerMotionState motion) {
        this.auramotion$motion = motion;
    }
}
